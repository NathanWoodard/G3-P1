#include <iostream>
#include "./evaluator.h"

using std::cout;
using std::endl;
using std::cin;
int main() {
    Evaluator e;

    // this stops code execution for
    char c;
    cin >> c;
}